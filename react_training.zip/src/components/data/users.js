export const users = [
    { id: 1, email: 'email@gmail.com', password: 'Password123' },
    { id: 2, email: 'email2@gmail.com', password: 'Password123' },
    { id: 3, email: 'email4@gmail.com', password: 'Password123' },
    { id: 4, email: 'email3@gmail.com', password: 'Password123' },
    { id: 5, email: 'email12@gmail.com', password: 'Password123' }
]