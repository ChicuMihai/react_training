import React, { Component } from 'react'

export default class CurrentUser extends Component {
    render() {
        return (
            <div>
                <p>User name:{this.props.name}</p>
                <button
                    className="btn btn-default"
                    onClick={() => this.props.setName("Maria")}
                >Edit User</button>

            </div>
        )
    }
}
